<?php

namespace App\Http\Controllers;
use App\Models\cms;
use App\Models\Checkout;
use Exception;
use Illuminate\Http\Request;

class cmscontroller extends Controller
{
    public function cms(){
        return view('cms.incms');
    }
    //function of insert cms
    public function incms(Request $req){
        try{
            $validator=$req->validate([
                'title'=>'required',
                'body'=>'required',
            ],[
                'title.required'=>'This field is mandatory',
                'body.required'=>'This field is mandatory'
            ]);
            if($validator){
                cms::insert([
                    'title'=>$req->title,
                    'body'=>$req->body,  
                ]);
                return redirect('/scms');
            }
        }
        catch(\Illuminate\Database\QueryException $e ){
            return view('aaa');
        }
       

    }
    //function of show cms
    public function scms(){
        try{
            $cms=cms::all();
        }
        catch(Exception $e){
            return view("cms.cmsnotfound");
        }
      
        return view('cms.scms',compact('cms'));
    }

    //function of edit cms
    public function ecms($id){
        try{
            $cms=cms::find($id);
        }
        catch(Exception $e){
            return view("cms.cmsnotfound");
        }
     
        return view('cms.ucms',compact('cms'));
    }

    //function of update cms
    public function ucms(Request $req){
        try{
            cms::where('id',$req->id)->update([
                'title'=>$req->title,
                'body'=>$req->body,
         
        
            ]);
            return redirect('/scms');
        }
        catch(\Illuminate\Database\QueryException $e ){
            return view('aaa');
        }
      
    }
    //function of delete cms
    public function delcms($id){
        cms::find($id)->delete();
       return redirect('/scms');
    }
      //search for address
      public function searchh(Request $request){
        // Get the search value from the request
        $search = $request->input('search');
    
        // Search in the name and bname columns from the users table
        $checkout = checkout::query()
            ->where('name', 'LIKE', "%{$search}%")
            ->orWhere('bname', 'LIKE', "%{$search}%")
            ->paginate(5);
    
        // Return the search view with the resluts compacted
        return view('order.address', compact('checkout'));
    }
    
}
