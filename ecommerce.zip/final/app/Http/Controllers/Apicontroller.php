<?php

namespace App\Http\Controllers;
use App\Models\product;
use App\Http\Resources\taskresource;
use App\Models\category;
use App\Models\slider;
use App\Models\orders;
use App\Models\cms;
use App\Models\User;
use App\Models\Coupon;
use App\Models\wishlist;
use Illuminate\Http\Request;

class Apicontroller extends Controller
{
    //Api of product
    public function product(){
        $product=product::all();
        return response(['product'=> taskresource::collection($product),'err'=> 0]);
    }
    //Api of slider
    public function slider(){
        $slider=slider::all();
        return response(['slider'=> taskresource::collection($slider),'err'=> 0]);

    }
    //Api of category 
    public function category(){
        $category=category::all();
        return response(['category'=> taskresource::collection($category),'err'=> 0]);  
    }
    //Api of category related product
    public function catpro($id){
        $product=product::where('category_id',$id)->get();
        return response(['product'=> taskresource::collection($product),'err'=> 0]);

    }
    //Api for coupon
    public function coupon(){
        $coupon=Coupon::all();
        return response(['coupon'=> taskresource::collection($coupon),'err'=> 0]);
    }
    //Api of order
    public function order($id){ 
      
        $user=User::where('email',$id)->first();
       
        $order=orders::where('user_id',$user->id)->get();
        return response(['order'  => taskresource::collection($order), 'msg' =>'sucess','err' =>0]);
    }
    //Api of cms
    public function cms(){
        $cms=cms::all();
        return response(['cms'=> taskresource::collection($cms),'err'=> 0]);
    }
    //Api for tracking
    public function track($id){
       
        $order=orders::where('order_id',$id)->get();
        return response(['track'  => taskresource::collection($order), 'msg' =>'sucess','err' =>0]);
    }
    //Api for wishlist
    public function addWish(Request $req)
    {
        $user = User::where('email', $req->email)->first();
        $wish = new wishlist();
        $wish->user_id = $user->id;
        $wish->product_id = $req->pid;
        $wish->save();
        return response()->json(['msg' => "Product Added to Wish List !"]);
    }


    // get user wish list
    public function getWish($id)
    {
        $wish = wishlist::where('User_id', $id)->get();
        foreach ($wish as $w) {
            $prod = Product::where('id', $w['product_id'])->first();
            $product[] = $prod;
        }
        return response(['wish' => taskresource::collection($product)]);
    
    }
    // delete user wishlist 
    public function delWish($id)
    {
        wishlist::where('product_id', $id)->delete();
        return response()->json(["msg" => "Wish Deleted !!"]);
    }
}
