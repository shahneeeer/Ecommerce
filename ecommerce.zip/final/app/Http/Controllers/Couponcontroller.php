<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use Illuminate\Http\Request;

class Couponcontroller extends Controller
{
    public function coupoun(){
        return view('coupons.incoupon');
    }
    //function for show coupon
    public function showc(){
        $user=Coupon::all();
        return view('coupons.showcoupon',compact('user'));
    }
    //function for edit coupoun
    public function editcoupon($id){
        $data=Coupon::find($id);
        return view('coupons.editcoupon',compact('data'));
    }
    //function for update coupoun
    public function updatec(Request $req){
    
            Coupon::where('id',$req->id)->update([
                'code'=>$req->code,
                'type'=>$req->type,
                'value'=>$req->value,
            ]);
            return redirect('/scoupon'); 
           
    }
    //function for delete coupoun
    public function deletec($id){
        Coupon::find($id)->delete();
        return redirect('/scoupon');
    }
    //function for insert coupoun
    public function incoupon(Request $req){
        $validator=$req->validate([
            'code'=>'required',
            'type'=>'required',
            'value'=>'required'
        ],[
            'code.required'=>'This field is manadtory',
            'type.required'=>'This field is manadtory',
            'value.required'=>'This field is manadtory',
        ]);
        if($validator){
            Coupon::insert([
                'code'=>$req->code,
                'type'=>$req->type,
                'value'=>$req->value,
            ]);
            return redirect('/scoupon');
        }
    }
}
