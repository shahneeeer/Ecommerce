<?php

namespace App\Http\Controllers;
use App\Models\role;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Models\contact;
use App\Models\Checkout;
use App\Models\Coupon;
use App\Models\orders;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;



class admin extends Controller
{
    //contact coming from front-end
    public function contact(){
        $user=contact::all();
        return view('contact',compact('user'));
    }
    //checkout controller
    public function checkout(){
        $checkout=Checkout::paginate(5);
        return view('order.address',compact('checkout'));
    }
    //order controller
    public function order(){
        $order=orders::paginate(5);
        return view('order.orders',compact('order'));
    }
    //edit order controller
    public function edit($id){
        $order=orders::find($id);
        return view('order.uorder',compact('order'));
    }
    //update order controller
    public function update(Request $req){
        orders::where('id',$req->id)->update([
            
            'status'=>$req->status,
            'order_id' =>$req->order,
        ]);
        return redirect('/order');
    }
    //controller of userregister and order count
    public function regusers()
    {
        $userCount = User::where('role', 'Customer')->count();
        $orderCount = orders::count();
        $coupounCount=Coupon::count();
        return view('chart', compact('userCount', 'orderCount','coupounCount'));
    }
//////////////////////////////



    public function user(){
        return view('user');
    }
    //To fetch roles in user table
    public function role(){
        $data=role::all();
        return view('user',compact('data'));
    }

    //search for user
    
    public function search(Request $request){
        // Get the search value from the request
        $search = $request->input('search');
    
        // Search in the firstname and email columns from the users table
        $user = User::query()
            ->where('firstname', 'LIKE', "%{$search}%")
            ->orWhere('email', 'LIKE', "%{$search}%")
            ->paginate(5);
    
        // Return the search view with the resluts compacted
        return view('showuser', compact('user'));
    }
   
    
    //insert user in the table
    
    public function insertuser(Request $req){
        try{
            $validate=$req->validate([
                'fname'=>'required',
                'lname'=>'required',
                'email'=>'required',
                'pass'=>'min:9|required_with:cpass|same:cpass',
                'cpass'=>'required|min:9',
                'status'=>'required',
                'roles'=>'required',
            ],[
                'fname.required'=>'This field is manadtory',
                'lname.required'=>'This field is manadtory',
                'email.requires'=>'This field is manadtory',
                'pass.required'=>'This field is manadtory',
                'cpass.required'=>'This field is manadtory',
                'status.required'=>'This field is manadtory',
                'roles.required'=>'This field is manadtory',
            ]);
            if($validate){
                User::insert([
                    'firstname'=>$req->fname,
                    'lastname'=>$req->lname,
                    'email'=>$req->email,
                    'password'=>Hash::make($req->pass),
                    'active'=>$req->status,
                    'role'=>$req->roles,
                    
                ]);
               // return back()->with('success',"DATA SAVED SUCESSFULLY");
                return redirect('/show');
            }
        }
        catch(\Illuminate\Database\QueryException $e ){
            return view('aaa');
        }

        
       
    }
    //fetch users in table
    public function showuser(){
        try{
            $user=User::paginate(6);
            
        }
        catch(\Exception $e){
            return view('bbb');
        }
        return view('showuser',compact('user'));
     
       
    }
    //delete users
    public function deleteuser($id){
        User::find($id)->delete();
        return redirect('/show');
    }
    //edit user
    public function edituser($id){
        try{
            $data=role::all();
            $use=User::find($id);
        }
        catch(\Exception $e){
            return view('bbb');
        }
      
        return view('edituser',compact('use','data'));
    }
    //update user
   public function updateuser(Request $req){
       try{
        User::where('id',$req->id)->update([
            'firstname'=>$req->fname,
            'lastname'=>$req->lname,
            'email'=>$req->email,
            'active'=>$req->status,
            'role'=>$req->roles,
    
        ]);
        return redirect('/show'); 
       }
       catch(\Illuminate\Database\QueryException $e ){
        return view('aaa');
    }
    
  
   }
   public function searchhh(Request $request){
    // Get the search value from the request
    $search = $request->input('search');

    // Search in the firstname and email columns from the users table
    $order = orders::query()
        ->where('name', 'LIKE', "%{$search}%")
        ->orWhere('user_id', 'LIKE', "%{$search}%")
        ->paginate(5);

    // Return the search view with the resluts compacted
    return view('order.orders', compact('order'));
}

  
    
    
    
}
