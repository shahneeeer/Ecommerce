<?php

namespace App\Http\Controllers;
use App\Models\configuration;

use Illuminate\Http\Request;

class configuratione extends Controller
{

    public function show(){
        return view("configuration.insert");
    }
    //function to show the table
    public function showconfig(){
        $user=configuration::all();
        return view("configuration.show",compact('user'));
    }

    //function of edit
    public function editconfig($id)
    {

        $use = configuration::find($id);
        return view('configuration.updateconfig', compact('use'));
    }

    //function of update
    public function updateconfig(Request $req)
    {
        configuration::where('id', $req->id)->update([
            'email' => $req->email,
            'name' => $req->name,


        ]);
        return redirect('/showconfig');
    }

    //function of delete
    public function deleteconfig($id)
    {
        configuration::find($id)->delete();
        return redirect('/showconfig');
    }

    
     //function to insert configuration
     public function insert(Request $req)
     {
         $validate = $req->validate([
             'email' => 'required',
             'name' => 'required',
         ], [
             'email.required' => 'This field is manadtory',
             'name.required' => 'This field is manadtory',
         ]);
         if ($validate) {
             configuration::insert([
                 'email' => $req->email,
                 'name' => $req->name,
             ]);
             return redirect('/showconfig');
         }
     }
}
