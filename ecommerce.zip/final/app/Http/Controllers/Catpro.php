<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use App\Models\image;

class Catpro extends Controller
{
    public function cat()
    {
        return view('catpro.insertcat');
    }
    //function to insert category
    public function insertcat(Request $req)
    {
        $validate = $req->validate([
            'name' => 'required',
            'description' => 'required',
        ], [
            'name.required' => 'This field is manadtory',
            'description.required' => 'This field is manadtory',
        ]);
        if ($validate) {
            category::insert([
                'name' => $req->name,
                'description' => $req->description,
            ]);
            return redirect('/showcat');
        }
    }
    //function to show category
    public function showcat()
    {

        $data = category::all();

        return view('catpro.showcat', compact('data'));
    }
    //function to delete catgeory
    public function deletecat($id)
    {
        category::find($id)->delete();
        return redirect('/showcat');
    }
    //function to edit category
    public function editcat($id)
    {

        $use = category::find($id);
        return view('catpro.updatecat', compact('use'));
    }
//function to update category
    public function updatecat(Request $req)
    {
        category::where('id', $req->cid)->update([
            'name' => $req->name,
            'description' => $req->description,


        ]);
        return redirect('/showcat');
    }

    //function to view product
    public function viewpro()
    {
        $abc = category::all();
        return view('catpro.insertpro', compact('abc'));
    }
    //function to insert product
    public function addpro(Request $req)
    {
        $validate = $req->validate(
            [
                'name' => 'required',
                'category' => 'required',
                'price' => 'required',
                'quantity' => 'required',
                'image' => 'mimes:png,jpg',
            ],
            [
                'name.required' => 'This field is manadtory',
                'category.required' => 'This field is manadatory',
                'price.required' => 'This field is manadatory',
                'quantity.required' => 'This field is manadatory',
                'image.mimes' => 'This field is manadtory'

            ]
        );
        if ($validate) {
            $filename = 'Image' . rand() . "." . $req->image->extension();
            if ($req->image->move(public_path('product/'), $filename)) {
                $cat = category::where('id', $req->category)->first();
                product::insert([
                    'name' => $req->name,
                    'type' => $cat->name,
                    'category_id' => $req->category,
                    'price' => $req->price,
                    'quantity' => $req->quantity,
                    'image' => $filename,
                ]);
            }


            return redirect('/viewpro');
        }
    }
    //function to show product
    public function showpro()
    {
        $data = product::all();
        return view('catpro.showpro', compact('data'));
    }
    //function to delete product
    public function deletepro($id)
    {
        product::find($id)->delete();
        return redirect('/viewpro');
    }
    //function to edit product
    public function editpro($id)
    {
        $cat = category::all();
        $data = product::find($id);
        return view('catpro.updatepro', compact('cat', 'data'));
    }
    //function to update product
    public function updatepro(Request $req)
    {
        $cat = category::where('id', $req->category)->first();
        $validate = $req->validate(
            [
                'name' => 'required',
                'category' => 'required',
                'price' => 'required',
                'quantity' => 'required',
            ],
            [
                'name.required' => 'This field is manadtory',
                'category.required' => 'This field is manadatory',
                'price.required' => 'This field is manadatory',
                'quantity.required' => 'This field is manadatory'

            ]
        );
        if ($validate) {

            product::where('id', $req->uid)->update([
                'name' => $req->name,
                'type' => $cat->name,
                'category_id' => $req->category,
                'price' => $req->price,
                'quantity' => $req->quantity,
            ]);
            return redirect('/viewpro');
        }
    }
    //function of image
    public function imgload($id)
    {
        $data = product::where('id', $id)->first();
        return view('catpro.imageupload', compact('data'));
    }
    //function of insert image
    public function upload(Request $req)
    {
        $filename = 'Image' . rand() . "." . $req->image->extension();
        if ($req->image->move(public_path('images/'), $filename)) {
            image::insert([
                'image' => $filename,
                'product_id' => $req->uid,
            ]);
            return redirect('/viewpro');
        }
    }
    //function of showing the image
    public function showing($id)
    {
        $pro = product::find($id);
        $imgs = image::all();
        return view('catpro.showing', compact('imgs', 'pro'));
    }
}
