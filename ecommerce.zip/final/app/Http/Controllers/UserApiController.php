<?php

namespace App\Http\Controllers;

use App\Http\Resources\taskresource;
use App\Models\Checkout;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\contact;
use App\Models\orders;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\order;
use App\Mail\RegisterUser;
use App\Mail\UserDetailsToAdmin;

use App\Models\configuration;
class UserApiController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'register', 'profile', 'checkout','contact']]);
    }
    //Api for register from front-end
    public function register(Request $req)
    {
        $admin=configuration::where('name' ,"=","Admin")->first();
        $validator = Validator::make($req->all(), [
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors());
        } else {
            $user = new User();
            $user->firstname = $req->firstname;
            $user->lastname = $req->lastname;
            $user->email = $req->email;
            $user->password = Hash::make($req->password);
            $user->active = 1;
            $user->role = 'Customer';
            if ($user->save()) {
            Mail::to($req->email)->send(new RegisterUser($req->all()));
            Mail::to($admin->email)->send(new UserDetailsToAdmin($req->all()));
        

                return response(['user' => new taskresource($user), 'msg' => 'register sucessfully', 'err' => 0]);
            } else {
                return response()->json(['msg' => 'failed registeration']);
            }
        }
    }
     //Api for login from front-end
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required|string|min:6'
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors());
        } else {
            if (!$token = auth()->guard('api')->attempt($validator->validated())) {
                return response()->json(['error' => 'email and password does not match to our records'], 401);
            }
            $users = User::where('email', $request->email)->first();
            return response()->json(['err' => 0, 'msg' => 'logged in', 'token' => $token, 'email' => $request->email, 'users' => $users], 200);
        }
    }
    public function respondWithToken($token)
    {
        return response()->json([
            'err' => 0,
            'token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->guard('api')->factory()->getTTL() * 60
        ]);
    }
     //Api for contact from front-end
    public function contact(Request $req)
    {
        $validator = Validator::make($req->all(), [
            'name' => 'required',
            'email' => 'required',
            'subject' => 'required',
            'message' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors());
        } else {
            $contact = new contact();
            $contact->name = $req->name;
            $contact->email = $req->email;
            $contact->subject = $req->subject;

            $contact->message = $req->message;

            if ($contact->save()) {

                return response(['contact' => new taskresource($contact), 'msg' => 'contacted', 'err' => 0]);
            } else {
                return response()->json(['msg' => 'failed registeration']);
            }
        }
    }
    public function profile()
    {
        $profile = auth('api')->user();
        return response()->json(['profile' => $profile]);
    }

 //Api for changepassword from front-end
    public function changepassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required|min:6|max:12',
            'new_password' => 'required|min:6|max:12',
            'confirm_password' => 'required|min:6|max:12|same:new_password',

        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors());
        } else {
            $user = $request->user();
            if (Hash::check($request->old_password, $user->password)) {
                $user->update([
                    'password' => Hash::make($request->new_password)
                ]);
                return response()->json([
                    'message' => "password successfully updated",
                    'status' => 1
                ], 200);
            } else {
                return response()->json([
                    'message' => "old password does not match",
                ], 400);
            }
        }
        return response()->json([
            'message' => "password successfully updated",
            'status' => 1
        ]);
    }
 //Api for checkout from front-end
    public function checkout(Request $req)
    {

        $users = User::where('email', $req->id)->first();
        $checkout = new Checkout();
        $checkout->name = $req->name;
        $checkout->email = $req->email;
        $checkout->address = $req->address;
        $checkout->mobile = $req->mobile;
        $checkout->bname = $req->bname;
        $checkout->bemail = $req->bemail;
        $checkout->baddress = $req->baddress;
        $checkout->bmobile = $req->bmobile;
        $checkout->user_id = $users->id;
        $checkout->checkamount=$req->camount;
        $a=$req->cart;
        foreach ($a as $c) {
            $order = new orders();
            $order->name = $c['name'];
            $order->price = $c['price'];
            $order->quantity = $c['quantity'];
            $order->status="processing";
            $order->user_id = $users->id;
            $order->order_id=rand();
            $order->save();
        }
      
        if ($checkout->save()) {
            Mail::to($req->id)->send(new order($req->all()));
            return response(['checkout' => new taskresource($checkout), 'msg' => 'SUBMITTED SUCESSFULLY', 'err' => 0]);
            
        } else {
            return response()->json(['msg' => 'failed regsitertaion']);
        }
    }
}
