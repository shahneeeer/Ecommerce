import axios from 'axios';
import { MAIN_URL } from '@/common/Url';
export function userLogin(data)
{
    return axios.post(`${MAIN_URL}logined`,data)
}
export function userRegister(data)
{
    return axios.post(`${MAIN_URL}register`,data)
}
export function contact(data)
{
    return axios.post(`${MAIN_URL}contact`,data)
}
export function product(data)
{
    return axios.get(`${MAIN_URL}product`,data)
}
export function slider(data)
{
    return axios.get(`${MAIN_URL}slider`,data)
}
export function checkout(data)
{
    return axios.post(`${MAIN_URL}checkout`,data)
}
export function coupon(data)
{
    return axios.get(`${MAIN_URL}coupon`,data)
}

export function cms(data)
{
    return axios.get(`${MAIN_URL}cms`,data)
}


export function profile()
{
    var token = localStorage.getItem('id_token');
    return axios.get(`${MAIN_URL}profile`, { headers: { "Authorization": `Bearer ${token}` } })
}
export function changepassword(data) {
    var token = localStorage.getItem('id_token');
    return axios.post(`${MAIN_URL}changepassword`, data, { headers: { "Authorization": `Bearer ${token}` } })
}
export function addToWish(data) {
    return axios.post(`${MAIN_URL}addwish`, data);
}

export function getWish() {
    let userId = localStorage.getItem('userId');
    return axios.get(`${MAIN_URL}getwish/` + userId);
}

export function removeWish(id)
 {
    return axios.get(`${MAIN_URL}delwish/` + id);
}


export default {userLogin,userRegister,contact,product,slider,checkout,profile,changepassword,cms,coupon,addToWish,getWish,removeWish};