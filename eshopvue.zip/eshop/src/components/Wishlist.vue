<template>
<div class="container">
  <div class="table-responsive cart_info">
    <table class="table table-condensed">
      <thead>
        <tr class="cart_menu">
          <td class="image">Item</td>
          <td class="description">Name</td>
          <td class="price">Price</td>
          <td class="quantity">Action</td>
          <td></td>
        </tr>
      </thead>
      <tbody>
        <tr class="cart-menu" v-for="wishh of wish" :key="wishh.id">
          <td class="cart_image">
            <img
              :src="url + wishh.image"
              alt=""
              width="100px"
              height="100px"
            />
            
          </td>
          <td class="cart_description">
            <h5>{{wishh.name}}</h5>
          </td>
          <td class="cart_price">
            <h5>₹ {{wishh.price}}</h5>
          </td>
          <td class="cart_delete">
            <button  class="btn btn-danger" @click="delWish(wishh.id)">
              <i >DELETE</i>
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
</template>

<script>

import {getWish} from '@/common/Service';
import {removeWish} from '@/common/Service';
export default {
name:"Wishlist",
data(){
    return{
    wish:undefined,
     url: "http://127.0.0.1:8000/product/",
  
   
    }
},
created(){
this.myWish()
},
methods:{
  myWish(){
    getWish()
   .then(res=>{
     this.wish = res.data.wish;
     console.log(this.wish);
   })
  },
  delWish(id){
    removeWish(id)

    .then(res=>{
      
      this.$swal(res.data.msg,'','success').then(()=>{
        window.location.reload()
      });
    })
  }
   
},


}
</script>

<style>

</style>