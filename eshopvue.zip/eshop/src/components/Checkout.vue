<template>
  <section id="cart_items">
    <div class="container">
      <div class="breadcrumbs">
        <ol class="breadcrumb">
          <li><a href="#">Home</a></li>
          <li class="active">Check out</li>
        </ol>
      </div>
      <!--/breadcrums-->

      <!--/checkout-options-->

      <!--/register-req-->
        <div class="review-payment">
        <h2>Review & Payment</h2>
      </div>
      <div class="table-responsive cart_info">
        <table class="table table-condensed">
          <thead>
            <tr class="cart_menu">
              <td class="image">Item</td>
              <td class="description">Name</td>
              <td class="price">Price</td>
        
             
              
            </tr>
          </thead>
          <tbody>
            <tr v-for="product in item" :key="product.id">
              <td class="cart_product">
                <a href=""
                  ><img
                    v-bind:src="server + product.image"
                    height="100"
                    width="100"
                    alt=""
                /></a>
              </td>
              <td class="cart_description">
                <h4>
                  <a href="">{{ product.name }}</a>
                </h4>
              </td>
              <td class="cart_price">
                <p>{{ product.price }}</p>
              </td>
            
              
              
            </tr><br>
            <tr>
              <td colspan="3">
                <div>
                  <h4>Apply this coupon and get discount</h4>                
                  </div>
                  <div v-for="a in coupons" :key="a.id" >
                    {{a.code}}
                  </div>
                  <form @submit.prevent="applyCoupon">
                    <label>Apply Coupon</label>
                      <input type="text" class="form-control" v-model="couponCode" />
                  <button  v-if="couponState==false" class="btn checkoutBtn" type="submit">Apply</button>
                    <button  v-else class="btn" type="button">Applied</button>
                   
                  </form>
              </td>
            </tr>

          </tbody>
        </table>
      </div>
      <div class="payment-options">
         <ul>
              
              <li> <h2>Rs {{ subtotal }}</h2> </li>
            </ul>
        <span><br>
         
        
        </span>
        
      </div>
       <div>
      <Gpay />
    </div>
        <div class="review-payment">
        <h2>Details</h2>
      </div>

      <div class="shopper-informations">
        <div class="row">
          <div class="col-sm-12 clearfix">
            <div class="bill-to">
              <p>Ship To</p>
              <div class="form-one">
                <form @submit.prevent="postcheckout">
                  <div class="form-group">
                    <input
                      type="email"
                      placeholder="Email*"
                      v-model="user.email"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.email.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.email.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.email.required"
                        >Email is required</span
                      >
                    </div>
                  </div>

                  <div class="form-group">
                    <input
                      type="text"
                      placeholder="Name*"
                      v-model="user.name"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.name.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.name.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.name.required"
                        >Name is required</span
                      >
                    </div>
                  </div>

                  <div class="form-group">
                    <input
                      type="text"
                      placeholder="Address*"
                      v-model="user.address"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.address.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.address.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.address.required"
                        >Address is required</span
                      >
                     
                    </div>
                  </div>

                  <div class="form-group">
                    <input
                      type="text"
                      placeholder="Mobile*"
                      v-model="user.mobile"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.mobile.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.mobile.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.mobile.required"
                        >Mobile is required</span
                      >
                    </div>
                  </div>

                  <p>Bill To</p>

                  <div class="form-group">
                    <input
                      type="email"
                      placeholder="Email*"
                      v-model="user.bemail"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.bemail.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.bemail.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.bemail.required"
                        >Email is required</span
                      >
                    </div>
                  </div>

                  <div class="form-group">
                    <input
                      type="text"
                      placeholder="Name*"
                      v-model="user.bname"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.bname.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.bname.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.bname.required"
                        >Name is required</span
                      >
                    </div>
                  </div>

                  <div class="form-group">
                    <input
                      type="text"
                      placeholder="Address*"
                      v-model="user.baddress"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.baddress.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.baddress.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.baddress.required"
                        >Address is required</span
                      >
                    
                    </div>
                  </div>

                  <div class="form-group">
                    <input
                      type="text"
                      placeholder="Mobile*"
                      v-model="user.bmobile"
                      class="form-control"
                      :class="{
                        'is-invalid': submitted && $v.user.bmobile.$error,
                      }"
                    />
                    <div
                      v-if="submitted && $v.user.bmobile.$error"
                      class="invalid-feedback"
                    >
                      <span v-if="!$v.user.bmobile.required"
                        >Mobile is required</span
                      >
                    </div>
                  </div>

                  <div class="form-group">
                    <button class="btn btn-primary">Place your Order</button>
                  </div>
                </form>
              </div>
            </div>
          </div>

        
        </div>
      </div>
    

      
 
    </div>
   
  </section>
  <!--/#cart_items-->
</template>

<script>
import { coupon } from "@/common/Service";
import { checkout } from "@/common/Service";
import { required ,email} from "vuelidate/lib/validators";
import Gpay from './Gpay.vue';
export default {
  name: "Checkout",
  components:{
 Gpay
  },
  data() {
    return {
      user:{
      email: "",
      name: "",
      address: "",
      mobile: "",
      bemail: "",
      bname: "",
      baddress: "",
      bmobile: "",
      },
      submitted:false,
      item: undefined,
      coupons:undefined,
      couponState:false,
      couponCode:"",
      couponDiscount:0,
      camount:undefined,
      server: "http://127.0.0.1:8000/product/",
     subtotal:localStorage.getItem('total'),
      
      
    };
  },
  validations:{
user:{
  email: {required,email},
      name: {required},
      address: {required},
      mobile: {required},
      bemail: {required,email},
      bname: {required},
      baddress: {required},
      bmobile: {required},
}
  },
  mounted() {
    this.item = JSON.parse(localStorage.getItem("myCart"));
    coupon().then((res)=>{
      if(res.data.err==0){
      this.coupons=res.data.coupon
      }
    })
  
    
     
  
  },
  methods: {
    postcheckout() {
      this.submitted=true;
      let formData = {
        
        name: this.user.name,
        email: this.user.email,
        address: this.user.address,
        mobile: this.user.mobile,
        bname: this.user.bname,
        bemail: this.user.bemail,
        baddress: this.user.baddress,
        bmobile: this.user.bmobile,
        id:localStorage.getItem('uid'),
        cart:JSON.parse(localStorage.getItem('myCart')),
        camount:this.subtotal
        
      };
      
      
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      console.log(formData)
      checkout(formData)
        .then((res) => {
          if (res.data.err == 0) {
            console.log(res.data.checkout)
            this.$swal(res.data.msg,'','success')
          
            this.$router.push({path: '/'});
          }
          else{
            alert("Something went wrong");
          }
        })
        .catch((err) => {
          console.log("SOmething Wrong " + err);
        });
    },
   
     
      delItem(product){
          let cart=this.item.indexOf(product);
          console.log(cart);
          this.item.splice(cart,1);
          localStorage.setItem('myCart',JSON.stringify(this.item))
      },
      applyCoupon(){
        this.coupons.forEach((coupon)=>{
          if (coupon.code==this.couponCode){
            this.coupon_id=coupon.id;
            this.couponDiscount=coupon.value
            this.subtotal-=this.couponDiscount;
            return;
          }
        });
        this.couponState=true;
        alert("coupon applied")

        
      }
  },
   
};
</script>

<style>
</style>